import React from 'react';

const BecomeASellerPage = () => {
    return <h1>Become A Seller</h1>
}

export default BecomeASellerPage;
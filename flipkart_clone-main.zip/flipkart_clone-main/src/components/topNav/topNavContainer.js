import React from 'react';
import TopNavComponent from './topNavComponent';

const TopNavContainer = () => {
    return <TopNavComponent />
}

export default TopNavContainer;
import React from "react";
import ModalComponent from "./modalComponent";

const ModalContainer = () => {
    return <ModalComponent />
}

export default ModalContainer;
import Modal from './modalContainer';
export default Modal;
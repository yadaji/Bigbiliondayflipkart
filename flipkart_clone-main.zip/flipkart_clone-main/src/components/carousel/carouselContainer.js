import React from 'react';
import CarouselComponent from './carouselComponent';

const CarouselContainer = () => {
    return <CarouselComponent />
}

export default CarouselContainer;
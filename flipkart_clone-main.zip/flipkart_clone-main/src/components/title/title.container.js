import React from "react";
import TitleComponent from "./title.component";

const TitleContainer = (props) => {
    return <TitleComponent {...props}/>
}

export default TitleContainer;
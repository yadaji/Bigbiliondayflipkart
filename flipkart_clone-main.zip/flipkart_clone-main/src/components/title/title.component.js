import React from "react";

const TitleComponent = ({ title }) => {
    return <h2> {title} </h2>
}

export default TitleComponent;
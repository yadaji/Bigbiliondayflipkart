import React from "react";
import SearchComponent from "./searchComponent";

const SearchContainer = () => {
    return <SearchComponent />
}

export default SearchContainer;
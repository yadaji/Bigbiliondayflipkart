import ProductsCarousel from './productsCarouselContainer';
export default ProductsCarousel;